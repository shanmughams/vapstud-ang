import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DepartmentModel } from '../models/department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  API_URL: string = "http://localhost:8080/api/v1/";
  constructor(private httpClient : HttpClient) { }

  getAllDepartments() : Observable<any> {
    return this.httpClient.get(this.API_URL + 'departments');
  }

  saveDepartment(dept: DepartmentModel) : Observable<any > {
    const httpOptions = {
      headers : new HttpHeaders({'Content-Type': 'application/json'})
    };
    return this.httpClient.post(this.API_URL+ 'departments',dept,httpOptions);
  }

  deleteDepartment(id: number) : Observable<number> {
    const httpOptions = {
      headers : new HttpHeaders({'Content-Type': 'application/json'})
    };
    return this.httpClient.post<number>(this.API_URL+ 'departments?id=', id, httpOptions);
  }

}
