import { Component, OnInit, ViewChild } from '@angular/core';
import {MatSort, Sort} from '@angular/material/sort';

import { MatTableDataSource } from '@angular/material/table';
import { DepartmentService } from 'src/app/services/department.service';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {

  gridListData : MatTableDataSource<any>;
  displayedColumns: string[] = ['deptid', 'deptname','ordno','actions'];

  searchKey : string;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private _deptService : DepartmentService) { }

  ngOnInit(): void {
    // setInterval(fillGrid(),1000);
    this.fillGrid();
  }

  fillGrid() {
    this._deptService.getAllDepartments()
    .subscribe(
      data => {
        this.gridListData = new MatTableDataSource(data);
        this.gridListData.sort = this.sort;
        this.gridListData.paginator = this.paginator;
      }
    );
  }

  applyFilter() {
    this.gridListData.filter = this.searchKey.trim().toLowerCase();
  }

  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }
}

