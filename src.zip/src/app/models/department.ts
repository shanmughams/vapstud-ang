export class DepartmentModel {
  deptId : number;
  deptName : string;
  ordNo : number;
  isactive : boolean;
  updatedBy : number;
  updatedAt : string;
}
